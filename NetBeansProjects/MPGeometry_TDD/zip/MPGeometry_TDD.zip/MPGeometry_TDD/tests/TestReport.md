# OUTCOME OF TESTS FOR PROJECT mpgeometry_tdd

As of Feb  7 2022 21:32:19

| ID | NAME | RESULT | COMMENTS |
| :----- |:------ | :---: | :---: |
| 1::1 | _01_Basics.Point_Constructors | PASSED | OK |
| 1::2 | _01_Basics.Point_Constructors | PASSED | OK |
| 2::1 | _01_Basics.Point_setX_Y | PASSED | OK |
| 2::2 | _01_Basics.Point_setX_Y | PASSED | OK |
| 3::1 | _01_Basics.Point_getX_Y | PASSED | OK |
| 3::2 | _01_Basics.Point_getX_Y | PASSED | OK |
| 4::1 | _02_Intermediate.Rectangle_Constructors | PASSED | OK |
| 4::2 | _02_Intermediate.Rectangle_Constructors | PASSED | OK |
| 5::1 | _02_Intermediate.Rectangle_setGeometry | PASSED | OK |
| 5::2 | _02_Intermediate.Rectangle_setGeometry | PASSED | OK |
| 6::1 | _02_Intermediate.Rectangle_getTopLeft | PASSED | OK |
| 6::2 | _02_Intermediate.Rectangle_getTopLeft | PASSED | OK |
| 7::1 | _02_Intermediate.Rectangle_isEmpty | PASSED | OK |
| 7::2 | _02_Intermediate.Rectangle_isEmpty | PASSED | OK |
| 8::1 | _03_Advanced.Rectangle_doOverlap | PASSED | OK |
| 8::2 | _03_Advanced.Rectangle_doOverlap | PASSED | OK |
| 8::3 | _03_Advanced.Rectangle_doOverlap | PASSED | OK |
| 9::1 | _03_Advanced.INTEGRATION_v_0inside | PASSED | OK |
| 10::1 | _03_Advanced.INTEGRATION_v_1inside | PASSED | OK |
| 11::1 | _03_Advanced.INTEGRATION_v_4inside | PASSED | OK |
| 12::1 | _03_Advanced.INTEGRATION_v_empty | PASSED | OK |
